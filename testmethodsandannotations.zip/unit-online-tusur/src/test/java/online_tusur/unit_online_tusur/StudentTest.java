package online_tusur.unit_online_tusur;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;


public class StudentTest {
	/*объект тестового класса  Student*/
	private Student s = new Student();	 	   

	    
/* проверка возраста студента при вводе граничного значения диапазона */
	  @Test
	  @Tag("Positive")
	  void test_Age_valid() {
		int age = 50;
		s.setAge(age);
	    int expectedAge = 50;
	    int actualsAge=s.getAge();
	    assertEquals(expectedAge, actualsAge);	

	  }
	  
/* проверка регистра при вводе фамилии */
	  @Test
	  @Tag("Positive")
	  void test_LastName_valid() {
		String fio = "зайцева";
		s.setLastName(fio);
	    String expectedLastName = "Зайцева";
	    String actualsLastName=s.getLastName();
	    assertEquals(expectedLastName, actualsLastName);	

	  }	  
	 
/* проверка ввода двойного имени*/
	  @Test
	  @Tag("Positive")
	  void test_FirstName_valid() {
		String name = "Марина-Екатерина";
		s.setFirstName(name);
	    String expectedFirstName = "Марина-Екатерина";
	    String actualsFirstName=s.getFirstName();
	    assertEquals(expectedFirstName, actualsFirstName);	

	  }	  	 
	  
/* проверка некорректного ввода фамилии*/
	  @Test
	  @Tag("Negative")
	  void test_LastName_invalid() {
		String fio = "374697";
		s.setLastName(fio);
	    String expectedLastName = "Некорректный ввод!";
	    String actualsLastName=s.getLastName();
	    assertEquals(expectedLastName, actualsLastName);	

	  }	
	 
/* проверка возраста студента при вводе пограничного значения*/
	  @Test
	  @Tag("Negative")
	  void test_Age_invalid() {
		int age = 17;
		s.setAge(age);
	    int expectedAge = 18;
	    int actualsAge=s.getAge();
	    assertEquals(expectedAge, actualsAge);	

	  }	 

/* проверка возраста студента при вводе отрицательного значения*/
	  @Test
	  @Tag("Negative")
	  void test_Age_invalid1() {
		int age = -20;
		s.setAge(age);
	    int expectedAge = 18;
	    int actualsAge=s.getAge();
	    assertEquals(expectedAge, actualsAge);	

	  }	 
	  
	  
}