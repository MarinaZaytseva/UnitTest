package online_tusur.unit_online_tusur;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import org.junit.jupiter.api.function.Executable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.api.DynamicTest;

//Параметризированный тест

class ParamTest {

 @ParameterizedTest
 @Tag("Positive")
 @CsvSource({"28,"+ "Марина, Зайцева, 36,"+ "Иван, Петров, 30,"+ "Петр, Иванов, 18"})
	
 void avgAge(int expected, ArgumentsAccessor arguments) {
	 Student[] students = {
			 new Student(arguments.getString(1), arguments.getString(2), Integer.parseInt(arguments.getString(3))),
			 new Student(arguments.getString(4), arguments.getString(5), Integer.parseInt(arguments.getString(6))),
			 new Student(arguments.getString(7), arguments.getString(8), Integer.parseInt(arguments.getString(9))),
			 };

	 assertEquals(expected, Student.avgAge(students));
	 }
	 
// Динамический тест для getAge()
 
@TestFactory
Collection<DynamicTest> dynamicTest1() {

Student s = new Student();

List<Integer> act = Arrays.asList(55,36,17);
List<Integer> exp = Arrays.asList(18,36,18);

ArrayList<DynamicTest> res = new ArrayList<>();

for (int i = 0; i < act.size(); i++) {

int x,y;
s.setAge(act.get(i));
y=s.getAge();
x=exp.get(i);

Executable exec = () -> assertEquals(x, y);

DynamicTest dTest = dynamicTest("test"+ i +". age = "+ x,exec);

res.add(dTest);
}

return res;
}

//Динамический тест для getFirstName()

@TestFactory
Collection<DynamicTest> dynamicTest2() {
	
	Student s = new Student();
	List<String> act = Arrays.asList("марина","Иван","пЕТР 1");
	List<String> exp = Arrays.asList("Марина","Иван","Петр 1");
	
	ArrayList<DynamicTest> res = new ArrayList<>();

	for (int i = 0; i < act.size(); i++) {

	String x,y;
	s.setFirstName(act.get(i));
	y=s.getFirstName();
	x=exp.get(i);

	Executable exec = () -> assertEquals(x, y);

	DynamicTest dTest = dynamicTest("test"+ i +". FirstName = "+ x,exec);

	res.add(dTest);
	}

	return res;
	}

//Динамический тест для getFirstName()

@TestFactory
Collection<DynamicTest> dynamicTest3() {
	
	Student s = new Student();
	List<String> act = Arrays.asList("Зайцева","ПеТрОв","Иванов-Сидоров");
	List<String> exp = Arrays.asList("Зайцева","Петров","Иванов-Сидоров");
	
	ArrayList<DynamicTest> res = new ArrayList<>();

	for (int i = 0; i < act.size(); i++) {

	String x,y;
	s.setLastName(act.get(i));
	y=s.getLastName();
	x=exp.get(i);

	Executable exec = () -> assertEquals(x, y);

	DynamicTest dTest = dynamicTest("test"+ i +". LastName = "+ x,exec);

	res.add(dTest);
	}

	return res;
	}
}
