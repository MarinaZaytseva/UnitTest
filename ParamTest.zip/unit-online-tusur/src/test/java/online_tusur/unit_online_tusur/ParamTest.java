package online_tusur.unit_online_tusur;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;

class ParamTest {

 @ParameterizedTest
 @Tag("Positive")
 @CsvSource({"28,"+ "Марина, Зайцева, 36,"+ "Иван, Петров, 30,"+ "Петр, Иванов, 18"})
	
 void avgAge(int expected, ArgumentsAccessor arguments) {
	 Student[] students = {
			 new Student(arguments.getString(1), arguments.getString(2), Integer.parseInt(arguments.getString(3))),
			 new Student(arguments.getString(4), arguments.getString(5), Integer.parseInt(arguments.getString(6))),
			 new Student(arguments.getString(7), arguments.getString(8), Integer.parseInt(arguments.getString(9))),
			 };

	 assertEquals(expected, Student.avgAge(students));
	 }
	 }
